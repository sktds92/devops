#! /bin/bash

#wysiwyg_editor download
cd ../plugins && git clone https://github.com/taqueci/redmine_wysiwyg_editor.git

#hidebar
cd ../plugins && git clone https://gitlab.com/bdemirkir/sidebar_hide.git

#puple themes download
cd ../themes && git clone https://github.com/mrliptontea/PurpleMine2.git
