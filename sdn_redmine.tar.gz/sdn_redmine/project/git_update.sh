#!/bin/bash

cd /usr/src/redmine/project/devops.git
git remote update
